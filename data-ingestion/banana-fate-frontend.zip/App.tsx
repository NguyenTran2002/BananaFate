import React, { useState, useCallback } from 'react';
import { AppStep, BananaMetadata } from './types';
import CameraCapture from './components/CameraCapture';
import PreviewScreen from './components/PreviewScreen';
import MetadataForm from './components/MetadataForm';
import { SpinnerIcon } from './components/icons/SpinnerIcon';
import { CheckIcon } from './components/icons/CheckIcon';
import { resizeImage } from './utils/imageUtils';
import WelcomeScreen from './components/WelcomeScreen';
import FallingBananasBackground from './components/FallingBananasBackground';

const App: React.FC = () => {
  const [step, setStep] = useState<AppStep>(AppStep.WELCOME);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [resizedImage, setResizedImage] = useState<string | null>(null);
  const [metadata, setMetadata] = useState<BananaMetadata>({
    batchId: '',
    bananaId: '',
    capturePerson: '',
    notes: '',
    captureTime: '',
    stage: '',
  });
  const [error, setError] = useState<string | null>(null);

  const handleError = useCallback((message: string) => {
    setError(message);
    setStep(AppStep.ERROR);
  }, []);
  
  const handleStartCapture = useCallback(() => {
    setStep(AppStep.CAPTURING);
  }, []);

  const handleReset = useCallback(() => {
    setCapturedImage(null);
    setResizedImage(null);
    setMetadata({
      batchId: '',
      bananaId: '',
      capturePerson: '',
      notes: '',
      captureTime: '',
      stage: '',
    });
    setError(null);
    setStep(AppStep.WELCOME);
  }, []);
  
  const handleRetake = useCallback(() => {
    setCapturedImage(null);
    setResizedImage(null);
    setStep(AppStep.CAPTURING);
  }, []);

  const handleCapture = useCallback(async (imageDataUrl: string) => {
    try {
      setCapturedImage(imageDataUrl);
      const resized = await resizeImage(imageDataUrl, 1024, 1024);
      setResizedImage(resized);
      setStep(AppStep.PREVIEW);
    } catch (err) {
      handleError('Failed to process image. Please try again.');
    }
  }, [handleError]);

  const handlePreviewConfirm = useCallback(() => {
    setMetadata(prev => ({
      ...prev,
      captureTime: new Date().toLocaleString(),
    }));
    setStep(AppStep.METADATA);
  }, []);

  const handleMetadataSubmit = useCallback((data: BananaMetadata) => {
    setMetadata(data);
    setStep(AppStep.UPLOADING);
    // Simulate upload
    setTimeout(() => {
      console.log("Simulating upload with data:", {
        image: resizedImage?.substring(0, 50) + '...', // log snippet
        metadata: data
      });
      setStep(AppStep.SUCCESS);
    }, 2000);
  }, [resizedImage]);

  const handleStartOver = useCallback(() => {
    setCapturedImage(null);
    setResizedImage(null);
    setMetadata(prev => ({ 
      ...prev, 
      bananaId: '', 
      notes: '',
      captureTime: '',
      stage: '',
    })); // Keep batchId and capturePerson
    setError(null);
    setStep(AppStep.CAPTURING);
  }, []);

  const renderStep = () => {
    switch (step) {
      case AppStep.WELCOME:
        return <WelcomeScreen onStart={handleStartCapture} />;
      case AppStep.CAPTURING:
        return <CameraCapture onCapture={handleCapture} onError={handleError} onClose={handleReset} />;
      case AppStep.PREVIEW:
        return (
          resizedImage && (
            <PreviewScreen
              imageDataUrl={resizedImage}
              onConfirm={handlePreviewConfirm}
              onRetake={handleRetake}
              onClose={handleReset}
            />
          )
        );
      case AppStep.METADATA:
        return (
          resizedImage && (
            <MetadataForm
              imageDataUrl={resizedImage}
              onSubmit={handleMetadataSubmit}
              initialMetadata={metadata}
              onRecapture={handleStartOver}
              onClose={handleReset}
            />
          )
        );
      case AppStep.UPLOADING:
        return (
          <div className="flex flex-col items-center justify-center h-full text-center p-8">
            <SpinnerIcon className="w-16 h-16 text-brand-yellow" />
            <h2 className="text-2xl font-bold mt-4">Uploading Banana...</h2>
            <p className="text-dark-subtext mt-2">
              Submitting image and metadata to the dataset.
            </p>
          </div>
        );
      case AppStep.SUCCESS:
        return (
          <div className="w-full h-full p-6 overflow-auto no-scrollbar">
            <div className="max-w-sm mx-auto text-center w-full flex flex-col items-center justify-center space-y-4">
              {resizedImage && (
                <div className="relative inline-block">
                  <div className="bg-brand-green p-1.5 rounded-lg shadow-xl">
                    <img
                      src={resizedImage}
                      alt="Uploaded banana"
                      className="w-40 h-40 object-cover rounded-md"
                    />
                  </div>
                  <div className="absolute -top-4 -right-4 bg-brand-green rounded-full p-2 border-4 border-ocean-deep shadow-lg">
                    <CheckIcon className="w-8 h-8 text-white" />
                  </div>
                </div>
              )}
  
              <div className="text-left bg-ocean-surface/50 p-4 rounded-lg w-full">
                <h3 className="text-lg font-bold mb-3 border-b border-gray-700 pb-2 text-dark-text">
                  Banana Details
                </h3>
                <div className="space-y-1 text-sm">
                  <p><strong className="font-medium text-dark-subtext w-28 inline-block">Capture Person:</strong> {metadata.capturePerson}</p>
                  <p><strong className="font-medium text-dark-subtext w-28 inline-block">Batch ID:</strong> {metadata.batchId}</p>
                  <p><strong className="font-medium text-dark-subtext w-28 inline-block">Banana ID:</strong> {metadata.bananaId}</p>
                  <p><strong className="font-medium text-dark-subtext w-28 inline-block">Capture Time:</strong> {metadata.captureTime}</p>
                  <p><strong className="font-medium text-dark-subtext w-28 inline-block">Stage:</strong> {metadata.stage}</p>
                  <p><strong className="font-medium text-dark-subtext w-28 inline-block">Notes:</strong> {metadata.notes || 'N/A'}</p>
                </div>
              </div>
  
              <button
                onClick={handleStartOver}
                className="w-full bg-brand-yellow text-gray-900 font-bold py-3 px-6 rounded-lg shadow-md hover:bg-yellow-400 transition-colors"
              >
                Capture Another
              </button>
              <button
                onClick={handleReset}
                className="font-semibold text-dark-subtext hover:text-white transition-colors py-2"
              >
                Return to Home
              </button>
            </div>
          </div>
        );
      case AppStep.ERROR:
        return (
          <div className="flex flex-col items-center justify-center h-full text-center p-8">
            <h2 className="text-2xl font-bold text-red-500">An Error Occurred</h2>
            <p className="text-dark-subtext mt-2">{error}</p>
            <button
              onClick={handleStartOver}
              className="mt-8 bg-brand-yellow text-gray-900 font-bold py-3 px-6 rounded-lg shadow-md hover:bg-yellow-400 transition-colors"
            >
              Try Again
            </button>
            <button
                onClick={handleReset}
                className="mt-4 font-semibold text-dark-subtext hover:text-white transition-colors py-2"
              >
                Return to Home
            </button>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <main className="min-h-screen flex flex-col items-center justify-center p-4 font-sans">
      <FallingBananasBackground />
      {/* Outer container for shape and positioning */}
      <div className="relative z-10 w-full max-w-md h-[90vh] max-h-[800px] mx-auto rounded-2xl shadow-2xl overflow-hidden">
        {/* Background layer for blur and color */}
        <div className="absolute inset-0 bg-ocean-surface/75 backdrop-blur-md rounded-2xl"></div>
        
        {/* Content layer */}
        <div className="relative z-10 h-full flex flex-col">
          <div className="p-6 flex-shrink-0 border-b border-gray-700/50">
            <h1 className="text-2xl font-bold text-center text-brand-yellow">
              {step === AppStep.WELCOME ? 'Banana Fate' : 
               step === AppStep.METADATA ? 'Document Banana' :
               step === AppStep.UPLOADING ? 'Uploading...' :
               step === AppStep.SUCCESS ? 'Banana Captured' : 'Capture Banana'}
            </h1>
          </div>
          <div className="flex-grow overflow-hidden">
            {renderStep()}
          </div>
        </div>
      </div>
    </main>
  );
};

export default App;
